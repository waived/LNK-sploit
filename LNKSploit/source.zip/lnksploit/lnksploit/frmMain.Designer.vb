﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.outerSkin = New lnksploit.MilitiaThemeControl()
        Me.lnkCredits = New System.Windows.Forms.LinkLabel()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnCompile = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.comboLocation = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtFilename = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rbCurl = New System.Windows.Forms.RadioButton()
        Me.rbBits = New System.Windows.Forms.RadioButton()
        Me.rbPs = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtUrl = New System.Windows.Forms.TextBox()
        Me.skinControl = New lnksploit.MilitiaControlBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.outerSkin.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'outerSkin
        '
        Me.outerSkin.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.outerSkin.Colors = New lnksploit.Bloom(-1) {}
        Me.outerSkin.Controls.Add(Me.lnkCredits)
        Me.outerSkin.Controls.Add(Me.GroupBox4)
        Me.outerSkin.Controls.Add(Me.GroupBox3)
        Me.outerSkin.Controls.Add(Me.GroupBox2)
        Me.outerSkin.Controls.Add(Me.GroupBox1)
        Me.outerSkin.Controls.Add(Me.skinControl)
        Me.outerSkin.Controls.Add(Me.PictureBox1)
        Me.outerSkin.Customization = ""
        Me.outerSkin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.outerSkin.Font = New System.Drawing.Font("MS PGothic", 12.75!)
        Me.outerSkin.Image = Nothing
        Me.outerSkin.Location = New System.Drawing.Point(0, 0)
        Me.outerSkin.MinimumSize = New System.Drawing.Size(80, 55)
        Me.outerSkin.Movable = True
        Me.outerSkin.Name = "outerSkin"
        Me.outerSkin.NoRounding = False
        Me.outerSkin.Sizable = False
        Me.outerSkin.Size = New System.Drawing.Size(534, 370)
        Me.outerSkin.SmartBounds = True
        Me.outerSkin.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.outerSkin.TabIndex = 0
        Me.outerSkin.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.outerSkin.Transparent = False
        '
        'lnkCredits
        '
        Me.lnkCredits.DisabledLinkColor = System.Drawing.Color.Black
        Me.lnkCredits.Font = New System.Drawing.Font("MS PGothic", 12.75!)
        Me.lnkCredits.LinkColor = System.Drawing.Color.Black
        Me.lnkCredits.Location = New System.Drawing.Point(12, 324)
        Me.lnkCredits.Name = "lnkCredits"
        Me.lnkCredits.Size = New System.Drawing.Size(510, 37)
        Me.lnkCredits.TabIndex = 6
        Me.lnkCredits.TabStop = True
        Me.lnkCredits.Text = "https://github.com/waived"
        Me.lnkCredits.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lnkCredits.VisitedLinkColor = System.Drawing.Color.Black
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.btnCompile)
        Me.GroupBox4.Font = New System.Drawing.Font("MS PGothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(346, 178)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(176, 144)
        Me.GroupBox4.TabIndex = 4
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Compile"
        '
        'btnCompile
        '
        Me.btnCompile.BackColor = System.Drawing.SystemColors.Control
        Me.btnCompile.Font = New System.Drawing.Font("MS PGothic", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCompile.Location = New System.Drawing.Point(17, 26)
        Me.btnCompile.Name = "btnCompile"
        Me.btnCompile.Size = New System.Drawing.Size(143, 95)
        Me.btnCompile.TabIndex = 0
        Me.btnCompile.Text = "☣"
        Me.btnCompile.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.comboLocation)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.txtFilename)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Font = New System.Drawing.Font("MS PGothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(177, 178)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(154, 144)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Settings"
        '
        'comboLocation
        '
        Me.comboLocation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboLocation.Font = New System.Drawing.Font("MS PGothic", 9.75!)
        Me.comboLocation.FormattingEnabled = True
        Me.comboLocation.Items.AddRange(New Object() {"Downloads", "Favorites", "User Profile", "Application Data", "Temporary Files"})
        Me.comboLocation.Location = New System.Drawing.Point(21, 100)
        Me.comboLocation.Name = "comboLocation"
        Me.comboLocation.Size = New System.Drawing.Size(114, 21)
        Me.comboLocation.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 84)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Location"
        '
        'txtFilename
        '
        Me.txtFilename.BackColor = System.Drawing.Color.White
        Me.txtFilename.Font = New System.Drawing.Font("MS PGothic", 9.75!)
        Me.txtFilename.Location = New System.Drawing.Point(21, 50)
        Me.txtFilename.Name = "txtFilename"
        Me.txtFilename.Size = New System.Drawing.Size(114, 20)
        Me.txtFilename.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Filename"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbCurl)
        Me.GroupBox2.Controls.Add(Me.rbBits)
        Me.GroupBox2.Controls.Add(Me.rbPs)
        Me.GroupBox2.Font = New System.Drawing.Font("MS PGothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(12, 178)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(150, 144)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Delivery"
        '
        'rbCurl
        '
        Me.rbCurl.AutoSize = True
        Me.rbCurl.Location = New System.Drawing.Point(26, 66)
        Me.rbCurl.Name = "rbCurl"
        Me.rbCurl.Size = New System.Drawing.Size(53, 17)
        Me.rbCurl.TabIndex = 2
        Me.rbCurl.Text = "Curl"
        Me.rbCurl.UseVisualStyleBackColor = True
        '
        'rbBits
        '
        Me.rbBits.AutoSize = True
        Me.rbBits.Location = New System.Drawing.Point(26, 101)
        Me.rbBits.Name = "rbBits"
        Me.rbBits.Size = New System.Drawing.Size(88, 17)
        Me.rbBits.TabIndex = 1
        Me.rbBits.Text = "Bitsadmin"
        Me.rbBits.UseVisualStyleBackColor = True
        '
        'rbPs
        '
        Me.rbPs.AutoSize = True
        Me.rbPs.Checked = True
        Me.rbPs.Location = New System.Drawing.Point(26, 32)
        Me.rbPs.Name = "rbPs"
        Me.rbPs.Size = New System.Drawing.Size(96, 17)
        Me.rbPs.TabIndex = 0
        Me.rbPs.TabStop = True
        Me.rbPs.Text = "Powershell"
        Me.rbPs.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtUrl)
        Me.GroupBox1.Font = New System.Drawing.Font("MS PGothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 110)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(510, 62)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Direct URL"
        '
        'txtUrl
        '
        Me.txtUrl.BackColor = System.Drawing.Color.White
        Me.txtUrl.Font = New System.Drawing.Font("MS PGothic", 9.75!)
        Me.txtUrl.Location = New System.Drawing.Point(17, 23)
        Me.txtUrl.Name = "txtUrl"
        Me.txtUrl.Size = New System.Drawing.Size(477, 20)
        Me.txtUrl.TabIndex = 3
        '
        'skinControl
        '
        Me.skinControl.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.skinControl.Colors = New lnksploit.Bloom(-1) {}
        Me.skinControl.Customization = ""
        Me.skinControl.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.skinControl.Image = Nothing
        Me.skinControl.Location = New System.Drawing.Point(456, 2)
        Me.skinControl.MaxButton = False
        Me.skinControl.MinButton = True
        Me.skinControl.Name = "skinControl"
        Me.skinControl.NoRounding = False
        Me.skinControl.Size = New System.Drawing.Size(66, 16)
        Me.skinControl.TabIndex = 1
        Me.skinControl.Text = "MilitiaControlBox1"
        Me.skinControl.Transparent = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.BackgroundImage = Global.lnksploit.My.Resources.Resources.logo
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox1.Location = New System.Drawing.Point(12, 32)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(510, 72)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(534, 370)
        Me.Controls.Add(Me.outerSkin)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(80, 55)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "LNKSploit 1.0"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.outerSkin.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents outerSkin As MilitiaThemeControl
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents skinControl As MilitiaControlBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtUrl As TextBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents lnkCredits As LinkLabel
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents rbCurl As RadioButton
    Friend WithEvents rbBits As RadioButton
    Friend WithEvents rbPs As RadioButton
    Friend WithEvents btnCompile As Button
    Friend WithEvents comboLocation As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtFilename As TextBox
    Friend WithEvents Label1 As Label
End Class
